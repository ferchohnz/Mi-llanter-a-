import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "llantera_ventas_v1";
const PRODUCTS_KEY = "llantera_productos_v1";

const DEFAULT_PRODUCTS = [
  { id: 1, nombre: "Reparación de llanta", categoria: "reparacion", precio: 80 },
  { id: 2, nombre: "Vulcanizado", categoria: "reparacion", precio: 60 },
  { id: 3, nombre: "Cambio de válvula", categoria: "reparacion", precio: 30 },
  { id: 4, nombre: "Balanceo", categoria: "reparacion", precio: 120 },
  { id: 5, nombre: "Aceite Motor 1L", categoria: "lubricante", precio: 150 },
  { id: 6, nombre: "Aceite Motor 4L", categoria: "lubricante", precio: 480 },
  { id: 7, nombre: "Aceite Transmisión", categoria: "lubricante", precio: 200 },
  { id: 8, nombre: 'Llanta 13"', categoria: "venta", precio: 850 },
  { id: 9, nombre: 'Llanta 14"', categoria: "venta", precio: 1050 },
  { id: 10, nombre: 'Llanta 15"', categoria: "venta", precio: 1250 },
];

const CAT_COLORS = {
  reparacion: { bg: "#1a3a2a", accent: "#22c55e", label: "Reparación" },
  lubricante: { bg: "#1a2a3a", accent: "#38bdf8", label: "Lubricante" },
  venta: { bg: "#2a1a3a", accent: "#a78bfa", label: "Venta Llanta" },
};

function today() { return new Date().toISOString().split("T")[0]; }
function fmtDate(d) { const [y, m, day] = d.split("-"); return `${day}/${m}/${y}`; }
function fmtMoney(n) { return "$" + Number(n).toLocaleString("es-MX", { minimumFractionDigits: 2 }); }
function currentMonth() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; }

function loadLocal(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}
function saveLocal(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch {}
}

export default function App() {
  const [mode, setMode] = useState("office");
  const [ventas, setVentas] = useState(() => loadLocal(STORAGE_KEY, []));
  const [products, setProducts] = useState(() => loadLocal(PRODUCTS_KEY, DEFAULT_PRODUCTS));
  const [activeTab, setActiveTab] = useState("vender");
  const [cart, setCart] = useState([]);
  const [clientNote, setClientNote] = useState("");
  const [saved, setSaved] = useState(false);
  const [filterCat, setFilterCat] = useState("all");
  const [newProd, setNewProd] = useState({ nombre: "", categoria: "reparacion", precio: "" });
  const [mobileTab, setMobileTab] = useState("hoy");
  const [toast, setToast] = useState("");

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 2500); };

  const saveVentas = useCallback((newV) => { setVentas(newV); saveLocal(STORAGE_KEY, newV); }, []);
  const saveProducts = useCallback((newP) => { setProducts(newP); saveLocal(PRODUCTS_KEY, newP); }, []);

  const addToCart = (prod) => {
    setCart(prev => {
      const ex = prev.find(x => x.id === prod.id);
      if (ex) return prev.map(x => x.id === prod.id ? { ...x, qty: x.qty + 1 } : x);
      return [...prev, { ...prod, qty: 1 }];
    });
  };

  const removeFromCart = (id) => setCart(prev => prev.filter(x => x.id !== id));
  const changeQty = (id, val) => {
    const n = parseInt(val);
    if (n < 1) return removeFromCart(id);
    setCart(prev => prev.map(x => x.id === id ? { ...x, qty: n } : x));
  };

  const cartTotal = cart.reduce((s, x) => s + x.precio * x.qty, 0);

  const registrarVenta = () => {
    if (!cart.length) return;
    const venta = {
      id: Date.now(),
      fecha: today(),
      hora: new Date().toLocaleTimeString("es-MX", { hour: "2-digit", minute: "2-digit" }),
      items: cart.map(x => ({ ...x })),
      total: cartTotal,
      nota: clientNote,
    };
    saveVentas([...ventas, venta]);
    setCart([]);
    setClientNote("");
    setSaved(true);
    showToast("✅ Venta registrada");
    setTimeout(() => setSaved(false), 2000);
  };

  const eliminarVenta = (id) => { saveVentas(ventas.filter(v => v.id !== id)); showToast("🗑️ Venta eliminada"); };
  const agregarProducto = () => {
    if (!newProd.nombre || !newProd.precio) return;
    saveProducts([...products, { ...newProd, id: Date.now(), precio: parseFloat(newProd.precio) }]);
    setNewProd({ nombre: "", categoria: "reparacion", precio: "" });
    showToast("✅ Producto agregado");
  };
  const eliminarProducto = (id) => { saveProducts(products.filter(p => p.id !== id)); showToast("🗑️ Producto eliminado"); };

  const ventasHoy = ventas.filter(v => v.fecha === today());
  const ventasMes = ventas.filter(v => v.fecha.startsWith(currentMonth()));

  const statsOf = (arr) => {
    const total = arr.reduce((s, v) => s + v.total, 0);
    const bycat = { reparacion: 0, lubricante: 0, venta: 0 };
    const byProd = {};
    arr.forEach(v => v.items.forEach(it => {
      bycat[it.categoria] = (bycat[it.categoria] || 0) + it.precio * it.qty;
      if (!byProd[it.nombre]) byProd[it.nombre] = { qty: 0, total: 0 };
      byProd[it.nombre].qty += it.qty;
      byProd[it.nombre].total += it.precio * it.qty;
    }));
    return { total, bycat, byProd };
  };

  const statsHoy = statsOf(ventasHoy);
  const statsMes = statsOf(ventasMes);
  const topProds = (byProd) => Object.entries(byProd).sort((a, b) => b[1].total - a[1].total).slice(0, 8);

  const S = { fontFamily: "'Segoe UI',sans-serif", background: "#0a0a0f", minHeight: "100vh", color: "#f1f5f9" };

  return (
    <div style={S}>
      {toast && (
        <div style={{ position:"fixed", top:20, left:"50%", transform:"translateX(-50%)", background:"#1e293b", border:"1px solid #f97316", color:"#fff", padding:"12px 28px", borderRadius:30, zIndex:9999, fontWeight:600, boxShadow:"0 8px 32px #f9731640", fontSize:15, whiteSpace:"nowrap" }}>
          {toast}
        </div>
      )}

      {/* Header */}
      <div style={{ background:"linear-gradient(135deg,#1c0a00,#0f172a)", borderBottom:"2px solid #f97316", padding:"14px 20px", display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:10 }}>
        <div style={{ display:"flex", alignItems:"center", gap:12 }}>
          <span style={{ fontSize:32 }}>🔧</span>
          <div>
            <div style={{ fontSize:20, fontWeight:800, color:"#f97316", letterSpacing:1 }}>MI LLANTERÍA</div>
            <div style={{ fontSize:11, color:"#94a3b8" }}>Sistema de Ventas</div>
          </div>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          {[["office","💻 Oficina"],["mobile","📱 Consulta"]].map(([k,l]) => (
            <button key={k} onClick={() => setMode(k)} style={{ padding:"8px 18px", borderRadius:20, border:"none", cursor:"pointer", fontWeight:700, fontSize:13, background: mode===k ? "#f97316":"#1e293b", color: mode===k ? "#fff":"#94a3b8" }}>{l}</button>
          ))}
        </div>
      </div>

      {/* MODO OFICINA */}
      {mode === "office" && (
        <div style={{ maxWidth:1100, margin:"0 auto", padding:"20px 16px" }}>
          <div style={{ display:"flex", gap:8, marginBottom:24, flexWrap:"wrap" }}>
            {[["vender","🧾 Nueva Venta"],["historial","📋 Historial Hoy"],["productos","📦 Productos"]].map(([k,l]) => (
              <button key={k} onClick={() => setActiveTab(k)} style={{ padding:"10px 22px", borderRadius:12, border:"none", cursor:"pointer", fontWeight:700, fontSize:14, background: activeTab===k ? "#f97316":"#1e293b", color: activeTab===k ? "#fff":"#94a3b8" }}>{l}</button>
            ))}
          </div>

          {activeTab === "vender" && (
            <div style={{ display:"grid", gridTemplateColumns:"1fr 340px", gap:20 }}>
              <div>
                <div style={{ display:"flex", gap:8, marginBottom:16, flexWrap:"wrap" }}>
                  {[["all","Todos"],["reparacion","🔧 Reparación"],["lubricante","🛢 Lubricante"],["venta","🔘 Llantas"]].map(([k,l]) => (
                    <button key={k} onClick={() => setFilterCat(k)} style={{ padding:"6px 14px", borderRadius:20, border:"none", cursor:"pointer", fontSize:13, fontWeight:600, background: filterCat===k ? "#f97316":"#1e293b", color: filterCat===k ? "#fff":"#94a3b8" }}>{l}</button>
                  ))}
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))", gap:12 }}>
                  {products.filter(p => filterCat==="all" || p.categoria===filterCat).map(p => {
                    const c = CAT_COLORS[p.categoria];
                    return (
                      <button key={p.id} onClick={() => addToCart(p)} style={{ background:c.bg, border:`1px solid ${c.accent}30`, borderRadius:14, padding:"16px 12px", cursor:"pointer", textAlign:"left", color:"#f1f5f9" }}>
                        <div style={{ fontSize:11, color:c.accent, fontWeight:700, marginBottom:4, textTransform:"uppercase" }}>{c.label}</div>
                        <div style={{ fontSize:14, fontWeight:600, marginBottom:8, lineHeight:1.3 }}>{p.nombre}</div>
                        <div style={{ fontSize:18, fontWeight:800, color:c.accent }}>{fmtMoney(p.precio)}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div style={{ background:"#111827", borderRadius:18, padding:20, border:"1px solid #1e293b", alignSelf:"start", position:"sticky", top:20 }}>
                <div style={{ fontSize:16, fontWeight:800, color:"#f97316", marginBottom:16 }}>🛒 Ticket de Venta</div>
                {cart.length === 0 ? (
                  <div style={{ color:"#475569", textAlign:"center", padding:"40px 0", fontSize:14 }}>Selecciona productos del catálogo</div>
                ) : (
                  <>
                    {cart.map(it => (
                      <div key={it.id} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:10, background:"#0f172a", borderRadius:10, padding:"10px 12px" }}>
                        <div style={{ flex:1 }}>
                          <div style={{ fontSize:13, fontWeight:600 }}>{it.nombre}</div>
                          <div style={{ fontSize:12, color:"#94a3b8" }}>{fmtMoney(it.precio)} c/u</div>
                        </div>
                        <input type="number" min={1} value={it.qty} onChange={e => changeQty(it.id, e.target.value)}
                          style={{ width:48, background:"#1e293b", border:"1px solid #334155", borderRadius:8, color:"#fff", padding:"4px 6px", fontSize:14, textAlign:"center" }} />
                        <button onClick={() => removeFromCart(it.id)} style={{ background:"none", border:"none", cursor:"pointer", color:"#ef4444", fontSize:18 }}>×</button>
                      </div>
                    ))}
                    <input placeholder="Nota (placa, cliente...)" value={clientNote} onChange={e => setClientNote(e.target.value)}
                      style={{ width:"100%", background:"#0f172a", border:"1px solid #334155", borderRadius:10, color:"#fff", padding:"10px 12px", fontSize:13, marginTop:8, boxSizing:"border-box" }} />
                    <div style={{ borderTop:"1px solid #1e293b", marginTop:16, paddingTop:14 }}>
                      <div style={{ display:"flex", justifyContent:"space-between", fontSize:20, fontWeight:800, color:"#f97316", marginBottom:16 }}>
                        <span>TOTAL</span><span>{fmtMoney(cartTotal)}</span>
                      </div>
                      <button onClick={registrarVenta} style={{ width:"100%", background: saved ? "#22c55e":"linear-gradient(135deg,#f97316,#ea580c)", border:"none", borderRadius:12, color:"#fff", padding:"14px 0", fontSize:16, fontWeight:800, cursor:"pointer" }}>
                        {saved ? "✅ ¡Registrada!" : "💾 Registrar Venta"}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {activeTab === "historial" && (
            <div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))", gap:14, marginBottom:24 }}>
                {[
                  { label:"Total del Día", value:fmtMoney(statsHoy.total), icon:"💰", color:"#f97316" },
                  { label:"Reparaciones", value:fmtMoney(statsHoy.bycat.reparacion), icon:"🔧", color:"#22c55e" },
                  { label:"Lubricantes", value:fmtMoney(statsHoy.bycat.lubricante), icon:"🛢", color:"#38bdf8" },
                  { label:"Venta Llantas", value:fmtMoney(statsHoy.bycat.venta), icon:"🔘", color:"#a78bfa" },
                  { label:"# Ventas", value:ventasHoy.length, icon:"🧾", color:"#fbbf24" },
                ].map((s,i) => (
                  <div key={i} style={{ background:"#111827", borderRadius:14, padding:"18px 16px", border:`1px solid ${s.color}30` }}>
                    <div style={{ fontSize:22 }}>{s.icon}</div>
                    <div style={{ fontSize:12, color:"#64748b", marginTop:4 }}>{s.label}</div>
                    <div style={{ fontSize:20, fontWeight:800, color:s.color, marginTop:2 }}>{s.value}</div>
                  </div>
                ))}
              </div>
              {ventasHoy.length === 0 ? (
                <div style={{ color:"#475569", textAlign:"center", padding:"60px 0" }}>No hay ventas registradas hoy</div>
              ) : [...ventasHoy].reverse().map(v => (
                <div key={v.id} style={{ background:"#111827", borderRadius:14, padding:"16px 20px", border:"1px solid #1e293b", marginBottom:12 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                    <div>
                      <span style={{ fontSize:13, color:"#64748b" }}>{v.hora}</span>
                      {v.nota && <span style={{ marginLeft:12, fontSize:13, color:"#f97316" }}>📝 {v.nota}</span>}
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                      <span style={{ fontSize:18, fontWeight:800, color:"#f97316" }}>{fmtMoney(v.total)}</span>
                      <button onClick={() => eliminarVenta(v.id)} style={{ background:"#450a0a", border:"1px solid #7f1d1d", borderRadius:8, color:"#ef4444", padding:"4px 10px", cursor:"pointer", fontSize:12 }}>Eliminar</button>
                    </div>
                  </div>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:8 }}>
                    {v.items.map((it,i) => {
                      const c = CAT_COLORS[it.categoria];
                      return <span key={i} style={{ background:c.bg, border:`1px solid ${c.accent}40`, borderRadius:20, padding:"4px 12px", fontSize:12, color:c.accent }}>{it.qty}× {it.nombre} – {fmtMoney(it.precio*it.qty)}</span>;
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "productos" && (
            <div>
              <div style={{ background:"#111827", borderRadius:16, padding:20, marginBottom:24, border:"1px solid #1e293b" }}>
                <div style={{ fontSize:15, fontWeight:700, color:"#f97316", marginBottom:14 }}>➕ Agregar Producto / Servicio</div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr auto auto auto", gap:10, alignItems:"end" }}>
                  <input placeholder="Nombre del producto o servicio" value={newProd.nombre} onChange={e => setNewProd({...newProd, nombre:e.target.value})}
                    style={{ background:"#0f172a", border:"1px solid #334155", borderRadius:10, color:"#fff", padding:"10px 14px", fontSize:14 }} />
                  <select value={newProd.categoria} onChange={e => setNewProd({...newProd, categoria:e.target.value})}
                    style={{ background:"#0f172a", border:"1px solid #334155", borderRadius:10, color:"#fff", padding:"10px 14px", fontSize:14 }}>
                    <option value="reparacion">Reparación</option>
                    <option value="lubricante">Lubricante</option>
                    <option value="venta">Venta Llanta</option>
                  </select>
                  <input placeholder="Precio" type="number" value={newProd.precio} onChange={e => setNewProd({...newProd, precio:e.target.value})}
                    style={{ background:"#0f172a", border:"1px solid #334155", borderRadius:10, color:"#fff", padding:"10px 14px", fontSize:14, width:110 }} />
                  <button onClick={agregarProducto} style={{ background:"#f97316", border:"none", borderRadius:10, color:"#fff", padding:"10px 20px", fontWeight:700, cursor:"pointer", fontSize:14 }}>Agregar</button>
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))", gap:12 }}>
                {products.map(p => {
                  const c = CAT_COLORS[p.categoria];
                  return (
                    <div key={p.id} style={{ background:c.bg, border:`1px solid ${c.accent}30`, borderRadius:14, padding:"14px 16px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                      <div>
                        <div style={{ fontSize:11, color:c.accent, fontWeight:700, textTransform:"uppercase" }}>{c.label}</div>
                        <div style={{ fontSize:14, fontWeight:600, marginTop:2 }}>{p.nombre}</div>
                        <div style={{ fontSize:17, fontWeight:800, color:c.accent, marginTop:4 }}>{fmtMoney(p.precio)}</div>
                      </div>
                      <button onClick={() => eliminarProducto(p.id)} style={{ background:"#450a0a", border:"none", borderRadius:8, color:"#ef4444", width:32, height:32, cursor:"pointer", fontSize:16 }}>×</button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODO MÓVIL */}
      {mode === "mobile" && (
        <div style={{ maxWidth:420, margin:"0 auto", padding:"16px 12px" }}>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:20 }}>
            {[["hoy","📅 Hoy"],["mes","📆 Este Mes"]].map(([k,l]) => (
              <button key={k} onClick={() => setMobileTab(k)} style={{ padding:"12px 0", borderRadius:12, border:"none", cursor:"pointer", fontWeight:700, fontSize:15, background: mobileTab===k ? "#f97316":"#1e293b", color: mobileTab===k ? "#fff":"#94a3b8" }}>{l}</button>
            ))}
          </div>
          {(() => {
            const stats = mobileTab==="hoy" ? statsHoy : statsMes;
            const vlist = mobileTab==="hoy" ? ventasHoy : ventasMes;
            const label = mobileTab==="hoy" ? `Hoy ${fmtDate(today())}` : "Mes actual";
            return (
              <>
                <div style={{ background:"linear-gradient(135deg,#7c2d12,#1c1917)", borderRadius:20, padding:"28px 20px", textAlign:"center", marginBottom:16, border:"1px solid #f9731640" }}>
                  <div style={{ fontSize:13, color:"#fb923c", marginBottom:4 }}>GANANCIA TOTAL · {label.toUpperCase()}</div>
                  <div style={{ fontSize:44, fontWeight:900, color:"#f97316" }}>{fmtMoney(stats.total)}</div>
                  <div style={{ fontSize:13, color:"#94a3b8", marginTop:6 }}>{vlist.length} ventas registradas</div>
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8, marginBottom:16 }}>
                  {[
                    { label:"Reparaciones", val:stats.bycat.reparacion, icon:"🔧", color:"#22c55e" },
                    { label:"Lubricantes", val:stats.bycat.lubricante, icon:"🛢", color:"#38bdf8" },
                    { label:"Llantas", val:stats.bycat.venta, icon:"🔘", color:"#a78bfa" },
                  ].map((s,i) => (
                    <div key={i} style={{ background:"#111827", borderRadius:14, padding:"14px 10px", textAlign:"center", border:`1px solid ${s.color}30` }}>
                      <div style={{ fontSize:20 }}>{s.icon}</div>
                      <div style={{ fontSize:10, color:"#64748b", marginTop:4 }}>{s.label}</div>
                      <div style={{ fontSize:14, fontWeight:800, color:s.color, marginTop:2 }}>{fmtMoney(s.val)}</div>
                    </div>
                  ))}
                </div>
                {Object.keys(stats.byProd).length > 0 && (
                  <div style={{ background:"#111827", borderRadius:16, padding:16, marginBottom:16, border:"1px solid #1e293b" }}>
                    <div style={{ fontSize:14, fontWeight:700, color:"#f97316", marginBottom:12 }}>🏆 Productos Vendidos</div>
                    {topProds(stats.byProd).map(([nombre, d], i, arr) => (
                      <div key={nombre} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"8px 0", borderBottom: i<arr.length-1 ? "1px solid #1e293b":"none" }}>
                        <div>
                          <div style={{ fontSize:13, fontWeight:600 }}>{nombre}</div>
                          <div style={{ fontSize:11, color:"#64748b" }}>{d.qty} unidades</div>
                        </div>
                        <div style={{ fontSize:14, fontWeight:800, color:"#f97316" }}>{fmtMoney(d.total)}</div>
                      </div>
                    ))}
                  </div>
                )}
                <div style={{ background:"#111827", borderRadius:16, padding:16, border:"1px solid #1e293b" }}>
                  <div style={{ fontSize:14, fontWeight:700, color:"#f97316", marginBottom:12 }}>🧾 Últimas Ventas</div>
                  {vlist.length === 0 ? (
                    <div style={{ color:"#475569", textAlign:"center", padding:"20px 0", fontSize:13 }}>Sin ventas aún</div>
                  ) : [...vlist].reverse().slice(0,10).map(v => (
                    <div key={v.id} style={{ padding:"10px 0", borderBottom:"1px solid #1e293b" }}>
                      <div style={{ display:"flex", justifyContent:"space-between" }}>
                        <span style={{ fontSize:12, color:"#64748b" }}>{mobileTab==="mes" ? fmtDate(v.fecha)+" ":""}{v.hora}</span>
                        <span style={{ fontSize:15, fontWeight:800, color:"#f97316" }}>{fmtMoney(v.total)}</span>
                      </div>
                      {v.nota && <div style={{ fontSize:12, color:"#fb923c", marginTop:2 }}>📝 {v.nota}</div>}
                      <div style={{ fontSize:12, color:"#94a3b8", marginTop:4 }}>{v.items.map(it => `${it.qty}× ${it.nombre}`).join(", ")}</div>
                    </div>
                  ))}
                </div>
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
}
